package com.ylt.vue_springboot_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VueSpringbootBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
